self.addEventListener('push',event=>{let d={};try{d=event.data.json()}catch(e){}event.waitUntil(self.registration.showNotification(d.title||'DOPE2000 WATCH',{body:d.body||'LIVEの開始を検知しました。',data:{url:d.url||'https://www.tiktok.com/@dope2000/live'}}))});
self.addEventListener('notificationclick',event=>{event.notification.close();event.waitUntil(clients.openWindow(event.notification.data.url))});
